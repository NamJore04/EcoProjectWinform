﻿namespace EcoProject
{
    partial class phan_tich_khi_thai
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.TB_NO = new Guna.UI2.WinForms.Guna2TextBox();
            this.NO = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.TB_CO = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.TB_H2S = new Guna.UI2.WinForms.Guna2TextBox();
            this.TB_ap_suat = new Guna.UI2.WinForms.Guna2TextBox();
            this.H2S = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.ap_suat = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.BoxNH3 = new Guna.UI2.WinForms.Guna2TextBox();
            this.BoxHg = new Guna.UI2.WinForms.Guna2TextBox();
            this.BoxO2 = new Guna.UI2.WinForms.Guna2TextBox();
            this.savechange = new Guna.UI2.WinForms.Guna2Button();
            this.NH3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.Hg = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.O2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2HtmlLabel9 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Panel1.SuspendLayout();
            this.guna2Panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // TB_NO
            // 
            this.TB_NO.Animated = true;
            this.TB_NO.AutoRoundedCorners = true;
            this.TB_NO.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.TB_NO.BorderRadius = 22;
            this.TB_NO.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TB_NO.DefaultText = "";
            this.TB_NO.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TB_NO.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TB_NO.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_NO.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_NO.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_NO.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TB_NO.ForeColor = System.Drawing.Color.Black;
            this.TB_NO.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_NO.Location = new System.Drawing.Point(856, 110);
            this.TB_NO.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.TB_NO.Name = "TB_NO";
            this.TB_NO.PasswordChar = '\0';
            this.TB_NO.PlaceholderText = "Nhập Dữ Liệu NO";
            this.TB_NO.SelectedText = "";
            this.TB_NO.Size = new System.Drawing.Size(412, 46);
            this.TB_NO.TabIndex = 21;
            // 
            // NO
            // 
            this.NO.AutoSize = false;
            this.NO.BackColor = System.Drawing.Color.Transparent;
            this.NO.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NO.Location = new System.Drawing.Point(850, 62);
            this.NO.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.NO.Name = "NO";
            this.NO.Size = new System.Drawing.Size(97, 41);
            this.NO.TabIndex = 20;
            this.NO.Text = "NO";
            // 
            // TB_CO
            // 
            this.TB_CO.Animated = true;
            this.TB_CO.AutoRoundedCorners = true;
            this.TB_CO.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.TB_CO.BorderRadius = 22;
            this.TB_CO.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TB_CO.DefaultText = "";
            this.TB_CO.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TB_CO.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TB_CO.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_CO.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_CO.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_CO.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TB_CO.ForeColor = System.Drawing.Color.Black;
            this.TB_CO.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_CO.Location = new System.Drawing.Point(140, 110);
            this.TB_CO.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.TB_CO.Name = "TB_CO";
            this.TB_CO.PasswordChar = '\0';
            this.TB_CO.PlaceholderText = "Nhập Dữ Liệu CO";
            this.TB_CO.SelectedText = "";
            this.TB_CO.Size = new System.Drawing.Size(412, 46);
            this.TB_CO.TabIndex = 19;
            // 
            // guna2HtmlLabel6
            // 
            this.guna2HtmlLabel6.AutoSize = false;
            this.guna2HtmlLabel6.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel6.Location = new System.Drawing.Point(134, 62);
            this.guna2HtmlLabel6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel6.Name = "guna2HtmlLabel6";
            this.guna2HtmlLabel6.Size = new System.Drawing.Size(163, 41);
            this.guna2HtmlLabel6.TabIndex = 18;
            this.guna2HtmlLabel6.Text = "CO";
            // 
            // TB_H2S
            // 
            this.TB_H2S.Animated = true;
            this.TB_H2S.AutoRoundedCorners = true;
            this.TB_H2S.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.TB_H2S.BorderRadius = 22;
            this.TB_H2S.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TB_H2S.DefaultText = "";
            this.TB_H2S.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TB_H2S.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TB_H2S.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_H2S.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_H2S.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_H2S.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TB_H2S.ForeColor = System.Drawing.Color.Black;
            this.TB_H2S.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_H2S.Location = new System.Drawing.Point(856, 334);
            this.TB_H2S.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.TB_H2S.Name = "TB_H2S";
            this.TB_H2S.PasswordChar = '\0';
            this.TB_H2S.PlaceholderText = "Nhập Dữ Liệu H2S";
            this.TB_H2S.SelectedText = "";
            this.TB_H2S.Size = new System.Drawing.Size(412, 46);
            this.TB_H2S.TabIndex = 16;
            // 
            // TB_ap_suat
            // 
            this.TB_ap_suat.Animated = true;
            this.TB_ap_suat.AutoRoundedCorners = true;
            this.TB_ap_suat.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.TB_ap_suat.BorderRadius = 22;
            this.TB_ap_suat.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TB_ap_suat.DefaultText = "";
            this.TB_ap_suat.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TB_ap_suat.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TB_ap_suat.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_ap_suat.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_ap_suat.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_ap_suat.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TB_ap_suat.ForeColor = System.Drawing.Color.Black;
            this.TB_ap_suat.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_ap_suat.Location = new System.Drawing.Point(856, 215);
            this.TB_ap_suat.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.TB_ap_suat.Name = "TB_ap_suat";
            this.TB_ap_suat.PasswordChar = '\0';
            this.TB_ap_suat.PlaceholderText = "Nhập Dữ Liệu Áp Suất";
            this.TB_ap_suat.SelectedText = "";
            this.TB_ap_suat.Size = new System.Drawing.Size(412, 46);
            this.TB_ap_suat.TabIndex = 17;
            // 
            // H2S
            // 
            this.H2S.AutoSize = false;
            this.H2S.BackColor = System.Drawing.Color.Transparent;
            this.H2S.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H2S.Location = new System.Drawing.Point(850, 281);
            this.H2S.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.H2S.Name = "H2S";
            this.H2S.Size = new System.Drawing.Size(138, 46);
            this.H2S.TabIndex = 13;
            this.H2S.Text = "H2S";
            // 
            // ap_suat
            // 
            this.ap_suat.AutoSize = false;
            this.ap_suat.BackColor = System.Drawing.Color.Transparent;
            this.ap_suat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ap_suat.Location = new System.Drawing.Point(856, 163);
            this.ap_suat.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ap_suat.Name = "ap_suat";
            this.ap_suat.Size = new System.Drawing.Size(138, 45);
            this.ap_suat.TabIndex = 14;
            this.ap_suat.Text = "Áp Suất";
            // 
            // BoxNH3
            // 
            this.BoxNH3.Animated = true;
            this.BoxNH3.AutoRoundedCorners = true;
            this.BoxNH3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.BoxNH3.BorderRadius = 22;
            this.BoxNH3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.BoxNH3.DefaultText = "";
            this.BoxNH3.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.BoxNH3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.BoxNH3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxNH3.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxNH3.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxNH3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BoxNH3.ForeColor = System.Drawing.Color.Black;
            this.BoxNH3.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxNH3.Location = new System.Drawing.Point(140, 447);
            this.BoxNH3.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.BoxNH3.Name = "BoxNH3";
            this.BoxNH3.PasswordChar = '\0';
            this.BoxNH3.PlaceholderText = "Nhập Dữ Liệu NH3";
            this.BoxNH3.SelectedText = "";
            this.BoxNH3.Size = new System.Drawing.Size(412, 46);
            this.BoxNH3.TabIndex = 11;
            // 
            // BoxHg
            // 
            this.BoxHg.Animated = true;
            this.BoxHg.AutoRoundedCorners = true;
            this.BoxHg.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.BoxHg.BorderRadius = 22;
            this.BoxHg.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.BoxHg.DefaultText = "";
            this.BoxHg.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.BoxHg.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.BoxHg.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxHg.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxHg.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxHg.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BoxHg.ForeColor = System.Drawing.Color.Black;
            this.BoxHg.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxHg.Location = new System.Drawing.Point(140, 334);
            this.BoxHg.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.BoxHg.Name = "BoxHg";
            this.BoxHg.PasswordChar = '\0';
            this.BoxHg.PlaceholderText = "Nhập Dữ Liệu Hg";
            this.BoxHg.SelectedText = "";
            this.BoxHg.Size = new System.Drawing.Size(412, 46);
            this.BoxHg.TabIndex = 11;
            // 
            // BoxO2
            // 
            this.BoxO2.Animated = true;
            this.BoxO2.AutoRoundedCorners = true;
            this.BoxO2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.BoxO2.BorderRadius = 22;
            this.BoxO2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.BoxO2.DefaultText = "";
            this.BoxO2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.BoxO2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.BoxO2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxO2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxO2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxO2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BoxO2.ForeColor = System.Drawing.Color.Black;
            this.BoxO2.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxO2.Location = new System.Drawing.Point(140, 215);
            this.BoxO2.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.BoxO2.Name = "BoxO2";
            this.BoxO2.PasswordChar = '\0';
            this.BoxO2.PlaceholderText = "Nhập Dữ Liệu O2";
            this.BoxO2.SelectedText = "";
            this.BoxO2.Size = new System.Drawing.Size(412, 46);
            this.BoxO2.TabIndex = 11;
            // 
            // savechange
            // 
            this.savechange.Animated = true;
            this.savechange.AutoRoundedCorners = true;
            this.savechange.BackColor = System.Drawing.Color.Transparent;
            this.savechange.BorderRadius = 21;
            this.savechange.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.savechange.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.savechange.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.savechange.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.savechange.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(167)))), ((int)(((byte)(67)))));
            this.savechange.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.savechange.ForeColor = System.Drawing.Color.White;
            this.savechange.IndicateFocus = true;
            this.savechange.Location = new System.Drawing.Point(517, 591);
            this.savechange.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.savechange.Name = "savechange";
            this.savechange.Size = new System.Drawing.Size(332, 45);
            this.savechange.TabIndex = 9;
            this.savechange.Text = "Lưu Dữ Liệu Hiện Trường";
            this.savechange.UseTransparentBackground = true;
            this.savechange.Click += new System.EventHandler(this.savechange_Click);
            // 
            // NH3
            // 
            this.NH3.AutoSize = false;
            this.NH3.BackColor = System.Drawing.Color.Transparent;
            this.NH3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NH3.Location = new System.Drawing.Point(135, 397);
            this.NH3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.NH3.Name = "NH3";
            this.NH3.Size = new System.Drawing.Size(162, 42);
            this.NH3.TabIndex = 2;
            this.NH3.Text = "NH3";
            // 
            // Hg
            // 
            this.Hg.AutoSize = false;
            this.Hg.BackColor = System.Drawing.Color.Transparent;
            this.Hg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Hg.Location = new System.Drawing.Point(134, 281);
            this.Hg.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Hg.Name = "Hg";
            this.Hg.Size = new System.Drawing.Size(127, 46);
            this.Hg.TabIndex = 2;
            this.Hg.Text = "Hg";
            // 
            // O2
            // 
            this.O2.AutoSize = false;
            this.O2.BackColor = System.Drawing.Color.Transparent;
            this.O2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.O2.Location = new System.Drawing.Point(134, 163);
            this.O2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.O2.Name = "O2";
            this.O2.Size = new System.Drawing.Size(86, 45);
            this.O2.TabIndex = 2;
            this.O2.Text = "O2";
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.AutoSize = false;
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(38, 2);
            this.guna2HtmlLabel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(615, 56);
            this.guna2HtmlLabel1.TabIndex = 1;
            this.guna2HtmlLabel1.Text = "Nhập Chi Tiết Dữ Liệu";
            this.guna2HtmlLabel1.Click += new System.EventHandler(this.guna2HtmlLabel1_Click);
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.Controls.Add(this.TB_NO);
            this.guna2Panel1.Controls.Add(this.NO);
            this.guna2Panel1.Controls.Add(this.TB_CO);
            this.guna2Panel1.Controls.Add(this.guna2HtmlLabel6);
            this.guna2Panel1.Controls.Add(this.TB_H2S);
            this.guna2Panel1.Controls.Add(this.TB_ap_suat);
            this.guna2Panel1.Controls.Add(this.H2S);
            this.guna2Panel1.Controls.Add(this.ap_suat);
            this.guna2Panel1.Controls.Add(this.BoxNH3);
            this.guna2Panel1.Controls.Add(this.BoxHg);
            this.guna2Panel1.Controls.Add(this.BoxO2);
            this.guna2Panel1.Controls.Add(this.savechange);
            this.guna2Panel1.Controls.Add(this.NH3);
            this.guna2Panel1.Controls.Add(this.Hg);
            this.guna2Panel1.Controls.Add(this.O2);
            this.guna2Panel1.Controls.Add(this.guna2HtmlLabel1);
            this.guna2Panel1.Location = new System.Drawing.Point(1, 89);
            this.guna2Panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.Size = new System.Drawing.Size(1449, 683);
            this.guna2Panel1.TabIndex = 10;
            // 
            // guna2Panel2
            // 
            this.guna2Panel2.Controls.Add(this.guna2HtmlLabel9);
            this.guna2Panel2.Location = new System.Drawing.Point(1, 11);
            this.guna2Panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel2.Name = "guna2Panel2";
            this.guna2Panel2.Size = new System.Drawing.Size(1449, 52);
            this.guna2Panel2.TabIndex = 11;
            // 
            // guna2HtmlLabel9
            // 
            this.guna2HtmlLabel9.AutoSize = false;
            this.guna2HtmlLabel9.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel9.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(188)))), ((int)(((byte)(109)))));
            this.guna2HtmlLabel9.Location = new System.Drawing.Point(11, 0);
            this.guna2HtmlLabel9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel9.Name = "guna2HtmlLabel9";
            this.guna2HtmlLabel9.Size = new System.Drawing.Size(866, 50);
            this.guna2HtmlLabel9.TabIndex = 0;
            this.guna2HtmlLabel9.Text = "Dữ Liệu Phân Tích Mẫu Khí Thải";
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 30;
            // 
            // phan_tich_khi_thai
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1473, 795);
            this.Controls.Add(this.guna2Panel1);
            this.Controls.Add(this.guna2Panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "phan_tich_khi_thai";
            this.Text = "NhapDuLieuPhanTichMauDat";
            this.guna2Panel1.ResumeLayout(false);
            this.guna2Panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2TextBox TB_NO;
        private Guna.UI2.WinForms.Guna2HtmlLabel NO;
        private Guna.UI2.WinForms.Guna2TextBox TB_CO;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel6;
        private Guna.UI2.WinForms.Guna2TextBox TB_H2S;
        private Guna.UI2.WinForms.Guna2TextBox TB_ap_suat;
        private Guna.UI2.WinForms.Guna2HtmlLabel H2S;
        private Guna.UI2.WinForms.Guna2HtmlLabel ap_suat;
        private Guna.UI2.WinForms.Guna2TextBox BoxNH3;
        private Guna.UI2.WinForms.Guna2TextBox BoxHg;
        private Guna.UI2.WinForms.Guna2TextBox BoxO2;
        private Guna.UI2.WinForms.Guna2Button savechange;
        private Guna.UI2.WinForms.Guna2HtmlLabel NH3;
        private Guna.UI2.WinForms.Guna2HtmlLabel Hg;
        private Guna.UI2.WinForms.Guna2HtmlLabel O2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel9;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
    }
}