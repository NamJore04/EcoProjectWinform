﻿namespace EcoProject.Nhap_lieu
{
    partial class hien_truong_khi_thai
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.guna2HtmlLabel9 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.TB_SO2 = new Guna.UI2.WinForms.Guna2TextBox();
            this.BoxPM = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.BoxNO2 = new Guna.UI2.WinForms.Guna2TextBox();
            this.savechange = new Guna.UI2.WinForms.Guna2Button();
            this.PM = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.NO2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.SO2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.TB_nhiet_do = new Guna.UI2.WinForms.Guna2TextBox();
            this.LB_nhiet_do = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.vi_tri_lay_mau = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2Panel2.SuspendLayout();
            this.guna2Panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2HtmlLabel9
            // 
            this.guna2HtmlLabel9.AutoSize = false;
            this.guna2HtmlLabel9.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel9.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(188)))), ((int)(((byte)(109)))));
            this.guna2HtmlLabel9.Location = new System.Drawing.Point(3, 2);
            this.guna2HtmlLabel9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel9.Name = "guna2HtmlLabel9";
            this.guna2HtmlLabel9.Size = new System.Drawing.Size(754, 71);
            this.guna2HtmlLabel9.TabIndex = 0;
            this.guna2HtmlLabel9.Text = "Dữ Liệu Hiện Trường Khí Thải";
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.AutoSize = false;
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(98, 62);
            this.guna2HtmlLabel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(333, 49);
            this.guna2HtmlLabel2.TabIndex = 13;
            this.guna2HtmlLabel2.Text = "Vị trí lấy mẫu";
            // 
            // TB_SO2
            // 
            this.TB_SO2.Animated = true;
            this.TB_SO2.AutoRoundedCorners = true;
            this.TB_SO2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.TB_SO2.BorderRadius = 22;
            this.TB_SO2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TB_SO2.DefaultText = "";
            this.TB_SO2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TB_SO2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TB_SO2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_SO2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_SO2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_SO2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TB_SO2.ForeColor = System.Drawing.Color.Black;
            this.TB_SO2.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_SO2.Location = new System.Drawing.Point(797, 119);
            this.TB_SO2.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.TB_SO2.Name = "TB_SO2";
            this.TB_SO2.PasswordChar = '\0';
            this.TB_SO2.PlaceholderText = "Nhập Dữ Liệu SO2";
            this.TB_SO2.SelectedText = "";
            this.TB_SO2.Size = new System.Drawing.Size(499, 46);
            this.TB_SO2.TabIndex = 11;
            // 
            // BoxPM
            // 
            this.BoxPM.Animated = true;
            this.BoxPM.AutoRoundedCorners = true;
            this.BoxPM.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.BoxPM.BorderRadius = 22;
            this.BoxPM.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.BoxPM.DefaultText = "";
            this.BoxPM.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.BoxPM.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.BoxPM.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxPM.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxPM.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxPM.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BoxPM.ForeColor = System.Drawing.Color.Black;
            this.BoxPM.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxPM.Location = new System.Drawing.Point(104, 436);
            this.BoxPM.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.BoxPM.Name = "BoxPM";
            this.BoxPM.PasswordChar = '\0';
            this.BoxPM.PlaceholderText = "Nhập Dữ Liệu PM";
            this.BoxPM.SelectedText = "";
            this.BoxPM.Size = new System.Drawing.Size(499, 46);
            this.BoxPM.TabIndex = 11;
            // 
            // guna2Panel2
            // 
            this.guna2Panel2.Controls.Add(this.guna2HtmlLabel9);
            this.guna2Panel2.Location = new System.Drawing.Point(12, 16);
            this.guna2Panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel2.Name = "guna2Panel2";
            this.guna2Panel2.Size = new System.Drawing.Size(1449, 75);
            this.guna2Panel2.TabIndex = 7;
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 30;
            // 
            // BoxNO2
            // 
            this.BoxNO2.Animated = true;
            this.BoxNO2.AutoRoundedCorners = true;
            this.BoxNO2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.BoxNO2.BorderRadius = 22;
            this.BoxNO2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.BoxNO2.DefaultText = "";
            this.BoxNO2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.BoxNO2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.BoxNO2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxNO2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxNO2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxNO2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BoxNO2.ForeColor = System.Drawing.Color.Black;
            this.BoxNO2.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxNO2.Location = new System.Drawing.Point(104, 279);
            this.BoxNO2.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.BoxNO2.Name = "BoxNO2";
            this.BoxNO2.PasswordChar = '\0';
            this.BoxNO2.PlaceholderText = "Nhập Dữ Liệu NO2";
            this.BoxNO2.SelectedText = "";
            this.BoxNO2.Size = new System.Drawing.Size(499, 46);
            this.BoxNO2.TabIndex = 11;
            // 
            // savechange
            // 
            this.savechange.Animated = true;
            this.savechange.AutoRoundedCorners = true;
            this.savechange.BackColor = System.Drawing.Color.Transparent;
            this.savechange.BorderRadius = 21;
            this.savechange.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.savechange.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.savechange.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.savechange.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.savechange.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(167)))), ((int)(((byte)(67)))));
            this.savechange.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.savechange.ForeColor = System.Drawing.Color.White;
            this.savechange.IndicateFocus = true;
            this.savechange.Location = new System.Drawing.Point(517, 591);
            this.savechange.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.savechange.Name = "savechange";
            this.savechange.Size = new System.Drawing.Size(332, 45);
            this.savechange.TabIndex = 9;
            this.savechange.Text = "Lưu Dữ Liệu Hiện Trường";
            this.savechange.UseTransparentBackground = true;
            this.savechange.Click += new System.EventHandler(this.savechange_Click);
            // 
            // PM
            // 
            this.PM.AutoSize = false;
            this.PM.BackColor = System.Drawing.Color.Transparent;
            this.PM.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PM.Location = new System.Drawing.Point(98, 385);
            this.PM.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PM.Name = "PM";
            this.PM.Size = new System.Drawing.Size(333, 44);
            this.PM.TabIndex = 2;
            this.PM.Text = "PM";
            // 
            // NO2
            // 
            this.NO2.AutoSize = false;
            this.NO2.BackColor = System.Drawing.Color.Transparent;
            this.NO2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NO2.Location = new System.Drawing.Point(98, 213);
            this.NO2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.NO2.Name = "NO2";
            this.NO2.Size = new System.Drawing.Size(272, 59);
            this.NO2.TabIndex = 2;
            this.NO2.Text = "NO2";
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.AutoSize = false;
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(26, 2);
            this.guna2HtmlLabel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(686, 65);
            this.guna2HtmlLabel1.TabIndex = 1;
            this.guna2HtmlLabel1.Text = "Nhập Chi Tiết Dữ Liệu";
            // 
            // SO2
            // 
            this.SO2.AutoSize = false;
            this.SO2.BackColor = System.Drawing.Color.Transparent;
            this.SO2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SO2.Location = new System.Drawing.Point(792, 62);
            this.SO2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.SO2.Name = "SO2";
            this.SO2.Size = new System.Drawing.Size(288, 49);
            this.SO2.TabIndex = 2;
            this.SO2.Text = "SO2";
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.Controls.Add(this.TB_nhiet_do);
            this.guna2Panel1.Controls.Add(this.LB_nhiet_do);
            this.guna2Panel1.Controls.Add(this.vi_tri_lay_mau);
            this.guna2Panel1.Controls.Add(this.guna2HtmlLabel2);
            this.guna2Panel1.Controls.Add(this.TB_SO2);
            this.guna2Panel1.Controls.Add(this.BoxPM);
            this.guna2Panel1.Controls.Add(this.BoxNO2);
            this.guna2Panel1.Controls.Add(this.savechange);
            this.guna2Panel1.Controls.Add(this.SO2);
            this.guna2Panel1.Controls.Add(this.PM);
            this.guna2Panel1.Controls.Add(this.NO2);
            this.guna2Panel1.Controls.Add(this.guna2HtmlLabel1);
            this.guna2Panel1.Location = new System.Drawing.Point(12, 96);
            this.guna2Panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.Size = new System.Drawing.Size(1449, 683);
            this.guna2Panel1.TabIndex = 6;
            // 
            // TB_nhiet_do
            // 
            this.TB_nhiet_do.Animated = true;
            this.TB_nhiet_do.AutoRoundedCorners = true;
            this.TB_nhiet_do.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.TB_nhiet_do.BorderRadius = 22;
            this.TB_nhiet_do.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TB_nhiet_do.DefaultText = "";
            this.TB_nhiet_do.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TB_nhiet_do.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TB_nhiet_do.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_nhiet_do.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_nhiet_do.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_nhiet_do.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TB_nhiet_do.ForeColor = System.Drawing.Color.Black;
            this.TB_nhiet_do.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_nhiet_do.Location = new System.Drawing.Point(797, 279);
            this.TB_nhiet_do.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.TB_nhiet_do.Name = "TB_nhiet_do";
            this.TB_nhiet_do.PasswordChar = '\0';
            this.TB_nhiet_do.PlaceholderText = "Nhập Dữ Liệu Nhiệt Độ";
            this.TB_nhiet_do.SelectedText = "";
            this.TB_nhiet_do.Size = new System.Drawing.Size(499, 46);
            this.TB_nhiet_do.TabIndex = 21;
            // 
            // LB_nhiet_do
            // 
            this.LB_nhiet_do.AutoSize = false;
            this.LB_nhiet_do.BackColor = System.Drawing.Color.Transparent;
            this.LB_nhiet_do.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB_nhiet_do.Location = new System.Drawing.Point(792, 213);
            this.LB_nhiet_do.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.LB_nhiet_do.Name = "LB_nhiet_do";
            this.LB_nhiet_do.Size = new System.Drawing.Size(297, 58);
            this.LB_nhiet_do.TabIndex = 20;
            this.LB_nhiet_do.Text = "Nhiệt Độ";
            // 
            // vi_tri_lay_mau
            // 
            this.vi_tri_lay_mau.Animated = true;
            this.vi_tri_lay_mau.AutoRoundedCorners = true;
            this.vi_tri_lay_mau.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.vi_tri_lay_mau.BorderRadius = 22;
            this.vi_tri_lay_mau.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.vi_tri_lay_mau.DefaultText = "";
            this.vi_tri_lay_mau.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.vi_tri_lay_mau.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.vi_tri_lay_mau.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.vi_tri_lay_mau.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.vi_tri_lay_mau.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.vi_tri_lay_mau.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.vi_tri_lay_mau.ForeColor = System.Drawing.Color.Black;
            this.vi_tri_lay_mau.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.vi_tri_lay_mau.Location = new System.Drawing.Point(104, 119);
            this.vi_tri_lay_mau.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.vi_tri_lay_mau.Name = "vi_tri_lay_mau";
            this.vi_tri_lay_mau.PasswordChar = '\0';
            this.vi_tri_lay_mau.PlaceholderText = "Nhập Vị Trí Lấy Mẫu";
            this.vi_tri_lay_mau.SelectedText = "";
            this.vi_tri_lay_mau.Size = new System.Drawing.Size(499, 46);
            this.vi_tri_lay_mau.TabIndex = 19;
            this.vi_tri_lay_mau.TextChanged += new System.EventHandler(this.vi_tri_lay_mau_TextChanged);
            // 
            // hien_truong_khi_thai
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1473, 795);
            this.Controls.Add(this.guna2Panel2);
            this.Controls.Add(this.guna2Panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "hien_truong_khi_thai";
            this.Text = "hien_truong_khi_thai";
            this.guna2Panel2.ResumeLayout(false);
            this.guna2Panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel9;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2TextBox TB_SO2;
        private Guna.UI2.WinForms.Guna2TextBox BoxPM;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2TextBox BoxNO2;
        private Guna.UI2.WinForms.Guna2Button savechange;
        private Guna.UI2.WinForms.Guna2HtmlLabel PM;
        private Guna.UI2.WinForms.Guna2HtmlLabel NO2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2HtmlLabel SO2;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2TextBox vi_tri_lay_mau;
        private Guna.UI2.WinForms.Guna2TextBox TB_nhiet_do;
        private Guna.UI2.WinForms.Guna2HtmlLabel LB_nhiet_do;
    }
}