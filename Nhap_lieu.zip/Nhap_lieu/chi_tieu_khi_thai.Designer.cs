﻿namespace EcoProject.Nhap_lieu
{
    partial class chi_tieu_khi_thai
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.SO2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel9 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.TB_SO2 = new Guna.UI2.WinForms.Guna2TextBox();
            this.BoxPM = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.BoxNO2 = new Guna.UI2.WinForms.Guna2TextBox();
            this.savechange = new Guna.UI2.WinForms.Guna2Button();
            this.PM = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.NO2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.TB_NO = new Guna.UI2.WinForms.Guna2TextBox();
            this.NO = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.TB_CO = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.TB_H2S = new Guna.UI2.WinForms.Guna2TextBox();
            this.TB_ap_suat = new Guna.UI2.WinForms.Guna2TextBox();
            this.H2S = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.ap_suat = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.BoxNH3 = new Guna.UI2.WinForms.Guna2TextBox();
            this.BoxHg = new Guna.UI2.WinForms.Guna2TextBox();
            this.BoxO2 = new Guna.UI2.WinForms.Guna2TextBox();
            this.NH3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.Hg = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.O2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.TB_nhiet_do = new Guna.UI2.WinForms.Guna2TextBox();
            this.LB_nhiet_do = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Panel2.SuspendLayout();
            this.guna2Panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // SO2
            // 
            this.SO2.AutoSize = false;
            this.SO2.BackColor = System.Drawing.Color.Transparent;
            this.SO2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SO2.Location = new System.Drawing.Point(792, 62);
            this.SO2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.SO2.Name = "SO2";
            this.SO2.Size = new System.Drawing.Size(288, 49);
            this.SO2.TabIndex = 2;
            this.SO2.Text = "SO2";
            // 
            // guna2HtmlLabel9
            // 
            this.guna2HtmlLabel9.AutoSize = false;
            this.guna2HtmlLabel9.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel9.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(188)))), ((int)(((byte)(109)))));
            this.guna2HtmlLabel9.Location = new System.Drawing.Point(3, 2);
            this.guna2HtmlLabel9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel9.Name = "guna2HtmlLabel9";
            this.guna2HtmlLabel9.Size = new System.Drawing.Size(754, 71);
            this.guna2HtmlLabel9.TabIndex = 0;
            this.guna2HtmlLabel9.Text = "Dữ Liệu Hiện Trường Khí Thải";
            // 
            // TB_SO2
            // 
            this.TB_SO2.Animated = true;
            this.TB_SO2.AutoRoundedCorners = true;
            this.TB_SO2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.TB_SO2.BorderRadius = 22;
            this.TB_SO2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TB_SO2.DefaultText = "";
            this.TB_SO2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TB_SO2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TB_SO2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_SO2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_SO2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_SO2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TB_SO2.ForeColor = System.Drawing.Color.Black;
            this.TB_SO2.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_SO2.Location = new System.Drawing.Point(797, 119);
            this.TB_SO2.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.TB_SO2.Name = "TB_SO2";
            this.TB_SO2.PasswordChar = '\0';
            this.TB_SO2.PlaceholderText = "Nhập Dữ Liệu SO2";
            this.TB_SO2.SelectedText = "";
            this.TB_SO2.Size = new System.Drawing.Size(499, 46);
            this.TB_SO2.TabIndex = 11;
            // 
            // BoxPM
            // 
            this.BoxPM.Animated = true;
            this.BoxPM.AutoRoundedCorners = true;
            this.BoxPM.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.BoxPM.BorderRadius = 22;
            this.BoxPM.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.BoxPM.DefaultText = "";
            this.BoxPM.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.BoxPM.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.BoxPM.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxPM.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxPM.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxPM.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BoxPM.ForeColor = System.Drawing.Color.Black;
            this.BoxPM.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxPM.Location = new System.Drawing.Point(104, 436);
            this.BoxPM.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.BoxPM.Name = "BoxPM";
            this.BoxPM.PasswordChar = '\0';
            this.BoxPM.PlaceholderText = "Nhập Dữ Liệu PM";
            this.BoxPM.SelectedText = "";
            this.BoxPM.Size = new System.Drawing.Size(499, 46);
            this.BoxPM.TabIndex = 11;
            // 
            // guna2Panel2
            // 
            this.guna2Panel2.Controls.Add(this.guna2HtmlLabel9);
            this.guna2Panel2.Location = new System.Drawing.Point(12, 16);
            this.guna2Panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel2.Name = "guna2Panel2";
            this.guna2Panel2.Size = new System.Drawing.Size(1449, 75);
            this.guna2Panel2.TabIndex = 9;
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 30;
            // 
            // BoxNO2
            // 
            this.BoxNO2.Animated = true;
            this.BoxNO2.AutoRoundedCorners = true;
            this.BoxNO2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.BoxNO2.BorderRadius = 22;
            this.BoxNO2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.BoxNO2.DefaultText = "";
            this.BoxNO2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.BoxNO2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.BoxNO2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxNO2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxNO2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxNO2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BoxNO2.ForeColor = System.Drawing.Color.Black;
            this.BoxNO2.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxNO2.Location = new System.Drawing.Point(104, 279);
            this.BoxNO2.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.BoxNO2.Name = "BoxNO2";
            this.BoxNO2.PasswordChar = '\0';
            this.BoxNO2.PlaceholderText = "Nhập Dữ Liệu NO2";
            this.BoxNO2.SelectedText = "";
            this.BoxNO2.Size = new System.Drawing.Size(499, 46);
            this.BoxNO2.TabIndex = 11;
            // 
            // savechange
            // 
            this.savechange.Animated = true;
            this.savechange.AutoRoundedCorners = true;
            this.savechange.BackColor = System.Drawing.Color.Transparent;
            this.savechange.BorderRadius = 21;
            this.savechange.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.savechange.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.savechange.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.savechange.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.savechange.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(167)))), ((int)(((byte)(67)))));
            this.savechange.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.savechange.ForeColor = System.Drawing.Color.White;
            this.savechange.IndicateFocus = true;
            this.savechange.Location = new System.Drawing.Point(531, 913);
            this.savechange.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.savechange.Name = "savechange";
            this.savechange.Size = new System.Drawing.Size(332, 45);
            this.savechange.TabIndex = 9;
            this.savechange.Text = "Lưu Dữ Liệu Hiện Trường";
            this.savechange.UseTransparentBackground = true;
            this.savechange.Click += new System.EventHandler(this.savechange_Click);
            // 
            // PM
            // 
            this.PM.AutoSize = false;
            this.PM.BackColor = System.Drawing.Color.Transparent;
            this.PM.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PM.Location = new System.Drawing.Point(98, 385);
            this.PM.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PM.Name = "PM";
            this.PM.Size = new System.Drawing.Size(333, 44);
            this.PM.TabIndex = 2;
            this.PM.Text = "PM";
            // 
            // NO2
            // 
            this.NO2.AutoSize = false;
            this.NO2.BackColor = System.Drawing.Color.Transparent;
            this.NO2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NO2.Location = new System.Drawing.Point(98, 213);
            this.NO2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.NO2.Name = "NO2";
            this.NO2.Size = new System.Drawing.Size(272, 59);
            this.NO2.TabIndex = 2;
            this.NO2.Text = "NO2";
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.AutoSize = false;
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(26, 2);
            this.guna2HtmlLabel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(686, 65);
            this.guna2HtmlLabel1.TabIndex = 1;
            this.guna2HtmlLabel1.Text = "Nhập Chi Tiết Dữ Liệu";
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.Controls.Add(this.TB_NO);
            this.guna2Panel1.Controls.Add(this.NO);
            this.guna2Panel1.Controls.Add(this.TB_CO);
            this.guna2Panel1.Controls.Add(this.guna2HtmlLabel6);
            this.guna2Panel1.Controls.Add(this.TB_H2S);
            this.guna2Panel1.Controls.Add(this.TB_ap_suat);
            this.guna2Panel1.Controls.Add(this.H2S);
            this.guna2Panel1.Controls.Add(this.ap_suat);
            this.guna2Panel1.Controls.Add(this.BoxNH3);
            this.guna2Panel1.Controls.Add(this.BoxHg);
            this.guna2Panel1.Controls.Add(this.BoxO2);
            this.guna2Panel1.Controls.Add(this.NH3);
            this.guna2Panel1.Controls.Add(this.Hg);
            this.guna2Panel1.Controls.Add(this.O2);
            this.guna2Panel1.Controls.Add(this.TB_nhiet_do);
            this.guna2Panel1.Controls.Add(this.LB_nhiet_do);
            this.guna2Panel1.Controls.Add(this.TB_SO2);
            this.guna2Panel1.Controls.Add(this.BoxPM);
            this.guna2Panel1.Controls.Add(this.BoxNO2);
            this.guna2Panel1.Controls.Add(this.savechange);
            this.guna2Panel1.Controls.Add(this.SO2);
            this.guna2Panel1.Controls.Add(this.PM);
            this.guna2Panel1.Controls.Add(this.NO2);
            this.guna2Panel1.Controls.Add(this.guna2HtmlLabel1);
            this.guna2Panel1.Location = new System.Drawing.Point(12, 96);
            this.guna2Panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.Size = new System.Drawing.Size(1449, 999);
            this.guna2Panel1.TabIndex = 8;
            // 
            // TB_NO
            // 
            this.TB_NO.Animated = true;
            this.TB_NO.AutoRoundedCorners = true;
            this.TB_NO.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.TB_NO.BorderRadius = 22;
            this.TB_NO.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TB_NO.DefaultText = "";
            this.TB_NO.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TB_NO.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TB_NO.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_NO.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_NO.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_NO.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TB_NO.ForeColor = System.Drawing.Color.Black;
            this.TB_NO.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_NO.Location = new System.Drawing.Point(803, 561);
            this.TB_NO.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.TB_NO.Name = "TB_NO";
            this.TB_NO.PasswordChar = '\0';
            this.TB_NO.PlaceholderText = "Nhập Dữ Liệu NO";
            this.TB_NO.SelectedText = "";
            this.TB_NO.Size = new System.Drawing.Size(493, 46);
            this.TB_NO.TabIndex = 35;
            // 
            // NO
            // 
            this.NO.AutoSize = false;
            this.NO.BackColor = System.Drawing.Color.Transparent;
            this.NO.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NO.Location = new System.Drawing.Point(797, 513);
            this.NO.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.NO.Name = "NO";
            this.NO.Size = new System.Drawing.Size(97, 41);
            this.NO.TabIndex = 34;
            this.NO.Text = "NO";
            // 
            // TB_CO
            // 
            this.TB_CO.Animated = true;
            this.TB_CO.AutoRoundedCorners = true;
            this.TB_CO.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.TB_CO.BorderRadius = 22;
            this.TB_CO.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TB_CO.DefaultText = "";
            this.TB_CO.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TB_CO.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TB_CO.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_CO.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_CO.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_CO.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TB_CO.ForeColor = System.Drawing.Color.Black;
            this.TB_CO.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_CO.Location = new System.Drawing.Point(106, 561);
            this.TB_CO.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.TB_CO.Name = "TB_CO";
            this.TB_CO.PasswordChar = '\0';
            this.TB_CO.PlaceholderText = "Nhập Dữ Liệu CO";
            this.TB_CO.SelectedText = "";
            this.TB_CO.Size = new System.Drawing.Size(497, 46);
            this.TB_CO.TabIndex = 33;
            // 
            // guna2HtmlLabel6
            // 
            this.guna2HtmlLabel6.AutoSize = false;
            this.guna2HtmlLabel6.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel6.Location = new System.Drawing.Point(100, 513);
            this.guna2HtmlLabel6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel6.Name = "guna2HtmlLabel6";
            this.guna2HtmlLabel6.Size = new System.Drawing.Size(163, 41);
            this.guna2HtmlLabel6.TabIndex = 32;
            this.guna2HtmlLabel6.Text = "CO";
            // 
            // TB_H2S
            // 
            this.TB_H2S.Animated = true;
            this.TB_H2S.AutoRoundedCorners = true;
            this.TB_H2S.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.TB_H2S.BorderRadius = 22;
            this.TB_H2S.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TB_H2S.DefaultText = "";
            this.TB_H2S.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TB_H2S.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TB_H2S.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_H2S.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_H2S.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_H2S.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TB_H2S.ForeColor = System.Drawing.Color.Black;
            this.TB_H2S.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_H2S.Location = new System.Drawing.Point(104, 119);
            this.TB_H2S.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.TB_H2S.Name = "TB_H2S";
            this.TB_H2S.PasswordChar = '\0';
            this.TB_H2S.PlaceholderText = "Nhập Dữ Liệu H2S";
            this.TB_H2S.SelectedText = "";
            this.TB_H2S.Size = new System.Drawing.Size(499, 46);
            this.TB_H2S.TabIndex = 30;
            // 
            // TB_ap_suat
            // 
            this.TB_ap_suat.Animated = true;
            this.TB_ap_suat.AutoRoundedCorners = true;
            this.TB_ap_suat.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.TB_ap_suat.BorderRadius = 22;
            this.TB_ap_suat.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TB_ap_suat.DefaultText = "";
            this.TB_ap_suat.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TB_ap_suat.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TB_ap_suat.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_ap_suat.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_ap_suat.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_ap_suat.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TB_ap_suat.ForeColor = System.Drawing.Color.Black;
            this.TB_ap_suat.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_ap_suat.Location = new System.Drawing.Point(803, 685);
            this.TB_ap_suat.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.TB_ap_suat.Name = "TB_ap_suat";
            this.TB_ap_suat.PasswordChar = '\0';
            this.TB_ap_suat.PlaceholderText = "Nhập Dữ Liệu Áp Suất";
            this.TB_ap_suat.SelectedText = "";
            this.TB_ap_suat.Size = new System.Drawing.Size(493, 46);
            this.TB_ap_suat.TabIndex = 31;
            // 
            // H2S
            // 
            this.H2S.AutoSize = false;
            this.H2S.BackColor = System.Drawing.Color.Transparent;
            this.H2S.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H2S.Location = new System.Drawing.Point(98, 62);
            this.H2S.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.H2S.Name = "H2S";
            this.H2S.Size = new System.Drawing.Size(138, 46);
            this.H2S.TabIndex = 28;
            this.H2S.Text = "H2S";
            // 
            // ap_suat
            // 
            this.ap_suat.AutoSize = false;
            this.ap_suat.BackColor = System.Drawing.Color.Transparent;
            this.ap_suat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ap_suat.Location = new System.Drawing.Point(803, 633);
            this.ap_suat.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ap_suat.Name = "ap_suat";
            this.ap_suat.Size = new System.Drawing.Size(138, 45);
            this.ap_suat.TabIndex = 29;
            this.ap_suat.Text = "Áp Suất";
            // 
            // BoxNH3
            // 
            this.BoxNH3.Animated = true;
            this.BoxNH3.AutoRoundedCorners = true;
            this.BoxNH3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.BoxNH3.BorderRadius = 22;
            this.BoxNH3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.BoxNH3.DefaultText = "";
            this.BoxNH3.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.BoxNH3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.BoxNH3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxNH3.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxNH3.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxNH3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BoxNH3.ForeColor = System.Drawing.Color.Black;
            this.BoxNH3.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxNH3.Location = new System.Drawing.Point(797, 436);
            this.BoxNH3.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.BoxNH3.Name = "BoxNH3";
            this.BoxNH3.PasswordChar = '\0';
            this.BoxNH3.PlaceholderText = "Nhập Dữ Liệu NH3";
            this.BoxNH3.SelectedText = "";
            this.BoxNH3.Size = new System.Drawing.Size(499, 46);
            this.BoxNH3.TabIndex = 25;
            // 
            // BoxHg
            // 
            this.BoxHg.Animated = true;
            this.BoxHg.AutoRoundedCorners = true;
            this.BoxHg.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.BoxHg.BorderRadius = 22;
            this.BoxHg.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.BoxHg.DefaultText = "";
            this.BoxHg.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.BoxHg.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.BoxHg.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxHg.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxHg.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxHg.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BoxHg.ForeColor = System.Drawing.Color.Black;
            this.BoxHg.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxHg.Location = new System.Drawing.Point(106, 804);
            this.BoxHg.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.BoxHg.Name = "BoxHg";
            this.BoxHg.PasswordChar = '\0';
            this.BoxHg.PlaceholderText = "Nhập Dữ Liệu Hg";
            this.BoxHg.SelectedText = "";
            this.BoxHg.Size = new System.Drawing.Size(497, 46);
            this.BoxHg.TabIndex = 26;
            // 
            // BoxO2
            // 
            this.BoxO2.Animated = true;
            this.BoxO2.AutoRoundedCorners = true;
            this.BoxO2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.BoxO2.BorderRadius = 22;
            this.BoxO2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.BoxO2.DefaultText = "";
            this.BoxO2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.BoxO2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.BoxO2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxO2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxO2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxO2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BoxO2.ForeColor = System.Drawing.Color.Black;
            this.BoxO2.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxO2.Location = new System.Drawing.Point(106, 685);
            this.BoxO2.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.BoxO2.Name = "BoxO2";
            this.BoxO2.PasswordChar = '\0';
            this.BoxO2.PlaceholderText = "Nhập Dữ Liệu O2";
            this.BoxO2.SelectedText = "";
            this.BoxO2.Size = new System.Drawing.Size(497, 46);
            this.BoxO2.TabIndex = 27;
            // 
            // NH3
            // 
            this.NH3.AutoSize = false;
            this.NH3.BackColor = System.Drawing.Color.Transparent;
            this.NH3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NH3.Location = new System.Drawing.Point(792, 386);
            this.NH3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.NH3.Name = "NH3";
            this.NH3.Size = new System.Drawing.Size(162, 42);
            this.NH3.TabIndex = 22;
            this.NH3.Text = "NH3";
            // 
            // Hg
            // 
            this.Hg.AutoSize = false;
            this.Hg.BackColor = System.Drawing.Color.Transparent;
            this.Hg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Hg.Location = new System.Drawing.Point(100, 751);
            this.Hg.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Hg.Name = "Hg";
            this.Hg.Size = new System.Drawing.Size(127, 46);
            this.Hg.TabIndex = 23;
            this.Hg.Text = "Hg";
            // 
            // O2
            // 
            this.O2.AutoSize = false;
            this.O2.BackColor = System.Drawing.Color.Transparent;
            this.O2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.O2.Location = new System.Drawing.Point(100, 633);
            this.O2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.O2.Name = "O2";
            this.O2.Size = new System.Drawing.Size(86, 45);
            this.O2.TabIndex = 24;
            this.O2.Text = "O2";
            // 
            // TB_nhiet_do
            // 
            this.TB_nhiet_do.Animated = true;
            this.TB_nhiet_do.AutoRoundedCorners = true;
            this.TB_nhiet_do.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.TB_nhiet_do.BorderRadius = 22;
            this.TB_nhiet_do.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TB_nhiet_do.DefaultText = "";
            this.TB_nhiet_do.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TB_nhiet_do.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TB_nhiet_do.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_nhiet_do.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_nhiet_do.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_nhiet_do.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TB_nhiet_do.ForeColor = System.Drawing.Color.Black;
            this.TB_nhiet_do.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_nhiet_do.Location = new System.Drawing.Point(797, 279);
            this.TB_nhiet_do.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.TB_nhiet_do.Name = "TB_nhiet_do";
            this.TB_nhiet_do.PasswordChar = '\0';
            this.TB_nhiet_do.PlaceholderText = "Nhập Dữ Liệu Nhiệt Độ";
            this.TB_nhiet_do.SelectedText = "";
            this.TB_nhiet_do.Size = new System.Drawing.Size(499, 46);
            this.TB_nhiet_do.TabIndex = 21;
            // 
            // LB_nhiet_do
            // 
            this.LB_nhiet_do.AutoSize = false;
            this.LB_nhiet_do.BackColor = System.Drawing.Color.Transparent;
            this.LB_nhiet_do.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB_nhiet_do.Location = new System.Drawing.Point(792, 213);
            this.LB_nhiet_do.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.LB_nhiet_do.Name = "LB_nhiet_do";
            this.LB_nhiet_do.Size = new System.Drawing.Size(297, 58);
            this.LB_nhiet_do.TabIndex = 20;
            this.LB_nhiet_do.Text = "Nhiệt Độ";
            // 
            // chi_tieu_khi_thai
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1473, 1106);
            this.Controls.Add(this.guna2Panel2);
            this.Controls.Add(this.guna2Panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "chi_tieu_khi_thai";
            this.Text = "chi_tieu_khi_thai";
            this.guna2Panel2.ResumeLayout(false);
            this.guna2Panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2HtmlLabel SO2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel9;
        private Guna.UI2.WinForms.Guna2TextBox TB_SO2;
        private Guna.UI2.WinForms.Guna2TextBox BoxPM;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2TextBox BoxNO2;
        private Guna.UI2.WinForms.Guna2Button savechange;
        private Guna.UI2.WinForms.Guna2HtmlLabel PM;
        private Guna.UI2.WinForms.Guna2HtmlLabel NO2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2TextBox TB_nhiet_do;
        private Guna.UI2.WinForms.Guna2HtmlLabel LB_nhiet_do;
        private Guna.UI2.WinForms.Guna2TextBox TB_NO;
        private Guna.UI2.WinForms.Guna2HtmlLabel NO;
        private Guna.UI2.WinForms.Guna2TextBox TB_CO;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel6;
        private Guna.UI2.WinForms.Guna2TextBox TB_H2S;
        private Guna.UI2.WinForms.Guna2TextBox TB_ap_suat;
        private Guna.UI2.WinForms.Guna2HtmlLabel H2S;
        private Guna.UI2.WinForms.Guna2HtmlLabel ap_suat;
        private Guna.UI2.WinForms.Guna2TextBox BoxNH3;
        private Guna.UI2.WinForms.Guna2TextBox BoxHg;
        private Guna.UI2.WinForms.Guna2TextBox BoxO2;
        private Guna.UI2.WinForms.Guna2HtmlLabel NH3;
        private Guna.UI2.WinForms.Guna2HtmlLabel Hg;
        private Guna.UI2.WinForms.Guna2HtmlLabel O2;
    }
}