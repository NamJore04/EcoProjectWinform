﻿namespace EcoProject
{
    partial class phan_tich_khong_khi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.TB_PM10 = new Guna.UI2.WinForms.Guna2TextBox();
            this.PM10 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.TB_SO2 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2HtmlLabel9 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.BoxO3 = new Guna.UI2.WinForms.Guna2TextBox();
            this.O3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.savechange = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel2.SuspendLayout();
            this.guna2Panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 30;
            // 
            // TB_PM10
            // 
            this.TB_PM10.Animated = true;
            this.TB_PM10.AutoRoundedCorners = true;
            this.TB_PM10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.TB_PM10.BorderRadius = 22;
            this.TB_PM10.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TB_PM10.DefaultText = "";
            this.TB_PM10.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TB_PM10.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TB_PM10.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_PM10.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_PM10.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_PM10.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TB_PM10.ForeColor = System.Drawing.Color.Black;
            this.TB_PM10.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_PM10.Location = new System.Drawing.Point(856, 110);
            this.TB_PM10.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.TB_PM10.Name = "TB_PM10";
            this.TB_PM10.PasswordChar = '\0';
            this.TB_PM10.PlaceholderText = "Nhập Dữ Liệu PM10";
            this.TB_PM10.SelectedText = "";
            this.TB_PM10.Size = new System.Drawing.Size(412, 46);
            this.TB_PM10.TabIndex = 21;
            // 
            // PM10
            // 
            this.PM10.AutoSize = false;
            this.PM10.BackColor = System.Drawing.Color.Transparent;
            this.PM10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PM10.Location = new System.Drawing.Point(850, 65);
            this.PM10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PM10.Name = "PM10";
            this.PM10.Size = new System.Drawing.Size(279, 38);
            this.PM10.TabIndex = 20;
            this.PM10.Text = "PM10";
            // 
            // TB_SO2
            // 
            this.TB_SO2.Animated = true;
            this.TB_SO2.AutoRoundedCorners = true;
            this.TB_SO2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.TB_SO2.BorderRadius = 22;
            this.TB_SO2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TB_SO2.DefaultText = "";
            this.TB_SO2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TB_SO2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TB_SO2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_SO2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_SO2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_SO2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TB_SO2.ForeColor = System.Drawing.Color.Black;
            this.TB_SO2.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_SO2.Location = new System.Drawing.Point(140, 110);
            this.TB_SO2.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.TB_SO2.Name = "TB_SO2";
            this.TB_SO2.PasswordChar = '\0';
            this.TB_SO2.PlaceholderText = "Nhập Dữ Liệu SO2";
            this.TB_SO2.SelectedText = "";
            this.TB_SO2.Size = new System.Drawing.Size(412, 46);
            this.TB_SO2.TabIndex = 19;
            // 
            // guna2HtmlLabel6
            // 
            this.guna2HtmlLabel6.AutoSize = false;
            this.guna2HtmlLabel6.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel6.Location = new System.Drawing.Point(134, 65);
            this.guna2HtmlLabel6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel6.Name = "guna2HtmlLabel6";
            this.guna2HtmlLabel6.Size = new System.Drawing.Size(265, 38);
            this.guna2HtmlLabel6.TabIndex = 18;
            this.guna2HtmlLabel6.Text = "SO2";
            // 
            // guna2Panel2
            // 
            this.guna2Panel2.Controls.Add(this.guna2HtmlLabel9);
            this.guna2Panel2.Location = new System.Drawing.Point(12, 17);
            this.guna2Panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel2.Name = "guna2Panel2";
            this.guna2Panel2.Size = new System.Drawing.Size(1449, 74);
            this.guna2Panel2.TabIndex = 13;
            // 
            // guna2HtmlLabel9
            // 
            this.guna2HtmlLabel9.AutoSize = false;
            this.guna2HtmlLabel9.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel9.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(188)))), ((int)(((byte)(109)))));
            this.guna2HtmlLabel9.Location = new System.Drawing.Point(3, 16);
            this.guna2HtmlLabel9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel9.Name = "guna2HtmlLabel9";
            this.guna2HtmlLabel9.Size = new System.Drawing.Size(767, 56);
            this.guna2HtmlLabel9.TabIndex = 0;
            this.guna2HtmlLabel9.Text = "Dữ Liệu Phân Tích Mẫu Không Khí";
            // 
            // BoxO3
            // 
            this.BoxO3.Animated = true;
            this.BoxO3.AutoRoundedCorners = true;
            this.BoxO3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.BoxO3.BorderRadius = 22;
            this.BoxO3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.BoxO3.DefaultText = "";
            this.BoxO3.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.BoxO3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.BoxO3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxO3.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxO3.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxO3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BoxO3.ForeColor = System.Drawing.Color.Black;
            this.BoxO3.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxO3.Location = new System.Drawing.Point(140, 243);
            this.BoxO3.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.BoxO3.Name = "BoxO3";
            this.BoxO3.PasswordChar = '\0';
            this.BoxO3.PlaceholderText = "Nhập Dữ Liệu O3";
            this.BoxO3.SelectedText = "";
            this.BoxO3.Size = new System.Drawing.Size(412, 46);
            this.BoxO3.TabIndex = 11;
            // 
            // O3
            // 
            this.O3.AutoSize = false;
            this.O3.BackColor = System.Drawing.Color.Transparent;
            this.O3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.O3.Location = new System.Drawing.Point(134, 191);
            this.O3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.O3.Name = "O3";
            this.O3.Size = new System.Drawing.Size(250, 45);
            this.O3.TabIndex = 2;
            this.O3.Text = "O3";
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.AutoSize = false;
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(21, 2);
            this.guna2HtmlLabel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(560, 59);
            this.guna2HtmlLabel1.TabIndex = 1;
            this.guna2HtmlLabel1.Text = "Nhập Chi Tiết Dữ Liệu";
            // 
            // savechange
            // 
            this.savechange.Animated = true;
            this.savechange.AutoRoundedCorners = true;
            this.savechange.BackColor = System.Drawing.Color.Transparent;
            this.savechange.BorderRadius = 21;
            this.savechange.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.savechange.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.savechange.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.savechange.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.savechange.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(167)))), ((int)(((byte)(67)))));
            this.savechange.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.savechange.ForeColor = System.Drawing.Color.White;
            this.savechange.IndicateFocus = true;
            this.savechange.Location = new System.Drawing.Point(517, 591);
            this.savechange.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.savechange.Name = "savechange";
            this.savechange.Size = new System.Drawing.Size(332, 45);
            this.savechange.TabIndex = 9;
            this.savechange.Text = "Lưu Dữ Liệu Hiện Trường";
            this.savechange.UseTransparentBackground = true;
            this.savechange.Click += new System.EventHandler(this.savechange_Click);
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.Controls.Add(this.TB_PM10);
            this.guna2Panel1.Controls.Add(this.PM10);
            this.guna2Panel1.Controls.Add(this.TB_SO2);
            this.guna2Panel1.Controls.Add(this.guna2HtmlLabel6);
            this.guna2Panel1.Controls.Add(this.BoxO3);
            this.guna2Panel1.Controls.Add(this.savechange);
            this.guna2Panel1.Controls.Add(this.O3);
            this.guna2Panel1.Controls.Add(this.guna2HtmlLabel1);
            this.guna2Panel1.Location = new System.Drawing.Point(12, 95);
            this.guna2Panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.Size = new System.Drawing.Size(1449, 683);
            this.guna2Panel1.TabIndex = 12;
            // 
            // phan_tich_khong_khi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1473, 795);
            this.Controls.Add(this.guna2Panel2);
            this.Controls.Add(this.guna2Panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "phan_tich_khong_khi";
            this.Text = "NhapDuLieuPhanTichMau";
            this.guna2Panel2.ResumeLayout(false);
            this.guna2Panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2TextBox TB_PM10;
        private Guna.UI2.WinForms.Guna2HtmlLabel PM10;
        private Guna.UI2.WinForms.Guna2TextBox TB_SO2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel6;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel9;
        private Guna.UI2.WinForms.Guna2TextBox BoxO3;
        private Guna.UI2.WinForms.Guna2HtmlLabel O3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2Button savechange;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
    }
}