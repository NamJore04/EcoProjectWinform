﻿namespace EcoProject.Nhap_lieu
{
    partial class chi_tieu_nuoc_mat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.TB_NO3 = new Guna.UI2.WinForms.Guna2TextBox();
            this.NO3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.TB_PO4 = new Guna.UI2.WinForms.Guna2TextBox();
            this.PO4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.TB_tongN = new Guna.UI2.WinForms.Guna2TextBox();
            this.tongP = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.TB_TSS = new Guna.UI2.WinForms.Guna2TextBox();
            this.TB_NH4 = new Guna.UI2.WinForms.Guna2TextBox();
            this.TSS = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.NH4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.BoxCOD = new Guna.UI2.WinForms.Guna2TextBox();
            this.BoxTOC = new Guna.UI2.WinForms.Guna2TextBox();
            this.BoxtongP = new Guna.UI2.WinForms.Guna2TextBox();
            this.COD = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.TOC = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.O2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.TB_nhiet_do = new Guna.UI2.WinForms.Guna2TextBox();
            this.LB_nhiet_do = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.BoxTDS = new Guna.UI2.WinForms.Guna2TextBox();
            this.BoxDO = new Guna.UI2.WinForms.Guna2TextBox();
            this.BoxpH = new Guna.UI2.WinForms.Guna2TextBox();
            this.savechange = new Guna.UI2.WinForms.Guna2Button();
            this.TDS = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.BO = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.pH = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2HtmlLabel9 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Panel1.SuspendLayout();
            this.guna2Panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.Controls.Add(this.TB_NO3);
            this.guna2Panel1.Controls.Add(this.NO3);
            this.guna2Panel1.Controls.Add(this.TB_PO4);
            this.guna2Panel1.Controls.Add(this.PO4);
            this.guna2Panel1.Controls.Add(this.TB_tongN);
            this.guna2Panel1.Controls.Add(this.tongP);
            this.guna2Panel1.Controls.Add(this.TB_TSS);
            this.guna2Panel1.Controls.Add(this.TB_NH4);
            this.guna2Panel1.Controls.Add(this.TSS);
            this.guna2Panel1.Controls.Add(this.NH4);
            this.guna2Panel1.Controls.Add(this.BoxCOD);
            this.guna2Panel1.Controls.Add(this.BoxTOC);
            this.guna2Panel1.Controls.Add(this.BoxtongP);
            this.guna2Panel1.Controls.Add(this.COD);
            this.guna2Panel1.Controls.Add(this.TOC);
            this.guna2Panel1.Controls.Add(this.O2);
            this.guna2Panel1.Controls.Add(this.TB_nhiet_do);
            this.guna2Panel1.Controls.Add(this.LB_nhiet_do);
            this.guna2Panel1.Controls.Add(this.BoxTDS);
            this.guna2Panel1.Controls.Add(this.BoxDO);
            this.guna2Panel1.Controls.Add(this.BoxpH);
            this.guna2Panel1.Controls.Add(this.savechange);
            this.guna2Panel1.Controls.Add(this.TDS);
            this.guna2Panel1.Controls.Add(this.BO);
            this.guna2Panel1.Controls.Add(this.pH);
            this.guna2Panel1.Controls.Add(this.guna2HtmlLabel1);
            this.guna2Panel1.Location = new System.Drawing.Point(12, 96);
            this.guna2Panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.Size = new System.Drawing.Size(1449, 999);
            this.guna2Panel1.TabIndex = 12;
            // 
            // TB_NO3
            // 
            this.TB_NO3.Animated = true;
            this.TB_NO3.AutoRoundedCorners = true;
            this.TB_NO3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.TB_NO3.BorderRadius = 22;
            this.TB_NO3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TB_NO3.DefaultText = "";
            this.TB_NO3.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TB_NO3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TB_NO3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_NO3.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_NO3.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_NO3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TB_NO3.ForeColor = System.Drawing.Color.Black;
            this.TB_NO3.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_NO3.Location = new System.Drawing.Point(107, 119);
            this.TB_NO3.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.TB_NO3.Name = "TB_NO3";
            this.TB_NO3.PasswordChar = '\0';
            this.TB_NO3.PlaceholderText = "Nhập Dữ Liệu NO3";
            this.TB_NO3.SelectedText = "";
            this.TB_NO3.Size = new System.Drawing.Size(485, 46);
            this.TB_NO3.TabIndex = 39;
            // 
            // NO3
            // 
            this.NO3.AutoSize = false;
            this.NO3.BackColor = System.Drawing.Color.Transparent;
            this.NO3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NO3.Location = new System.Drawing.Point(101, 74);
            this.NO3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.NO3.Name = "NO3";
            this.NO3.Size = new System.Drawing.Size(356, 38);
            this.NO3.TabIndex = 38;
            this.NO3.Text = "NO3";
            // 
            // TB_PO4
            // 
            this.TB_PO4.Animated = true;
            this.TB_PO4.AutoRoundedCorners = true;
            this.TB_PO4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.TB_PO4.BorderRadius = 22;
            this.TB_PO4.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TB_PO4.DefaultText = "";
            this.TB_PO4.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TB_PO4.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TB_PO4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_PO4.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_PO4.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_PO4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TB_PO4.ForeColor = System.Drawing.Color.Black;
            this.TB_PO4.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_PO4.Location = new System.Drawing.Point(797, 574);
            this.TB_PO4.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.TB_PO4.Name = "TB_PO4";
            this.TB_PO4.PasswordChar = '\0';
            this.TB_PO4.PlaceholderText = "Nhập Dữ Liệu PO4";
            this.TB_PO4.SelectedText = "";
            this.TB_PO4.Size = new System.Drawing.Size(499, 46);
            this.TB_PO4.TabIndex = 37;
            // 
            // PO4
            // 
            this.PO4.AutoSize = false;
            this.PO4.BackColor = System.Drawing.Color.Transparent;
            this.PO4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PO4.Location = new System.Drawing.Point(791, 526);
            this.PO4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PO4.Name = "PO4";
            this.PO4.Size = new System.Drawing.Size(218, 41);
            this.PO4.TabIndex = 36;
            this.PO4.Text = "PO4";
            // 
            // TB_tongN
            // 
            this.TB_tongN.Animated = true;
            this.TB_tongN.AutoRoundedCorners = true;
            this.TB_tongN.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.TB_tongN.BorderRadius = 22;
            this.TB_tongN.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TB_tongN.DefaultText = "";
            this.TB_tongN.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TB_tongN.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TB_tongN.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_tongN.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_tongN.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_tongN.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TB_tongN.ForeColor = System.Drawing.Color.Black;
            this.TB_tongN.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_tongN.Location = new System.Drawing.Point(107, 574);
            this.TB_tongN.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.TB_tongN.Name = "TB_tongN";
            this.TB_tongN.PasswordChar = '\0';
            this.TB_tongN.PlaceholderText = "Nhập Dữ Liệu Tổng Nitrogen";
            this.TB_tongN.SelectedText = "";
            this.TB_tongN.Size = new System.Drawing.Size(496, 46);
            this.TB_tongN.TabIndex = 35;
            // 
            // tongP
            // 
            this.tongP.AutoSize = false;
            this.tongP.BackColor = System.Drawing.Color.Transparent;
            this.tongP.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tongP.Location = new System.Drawing.Point(101, 526);
            this.tongP.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tongP.Name = "tongP";
            this.tongP.Size = new System.Drawing.Size(269, 41);
            this.tongP.TabIndex = 34;
            this.tongP.Text = "Tổng Nitrogen";
            // 
            // TB_TSS
            // 
            this.TB_TSS.Animated = true;
            this.TB_TSS.AutoRoundedCorners = true;
            this.TB_TSS.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.TB_TSS.BorderRadius = 22;
            this.TB_TSS.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TB_TSS.DefaultText = "";
            this.TB_TSS.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TB_TSS.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TB_TSS.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_TSS.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_TSS.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_TSS.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TB_TSS.ForeColor = System.Drawing.Color.Black;
            this.TB_TSS.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_TSS.Location = new System.Drawing.Point(797, 825);
            this.TB_TSS.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.TB_TSS.Name = "TB_TSS";
            this.TB_TSS.PasswordChar = '\0';
            this.TB_TSS.PlaceholderText = "Nhập Dữ Liệu TSS";
            this.TB_TSS.SelectedText = "";
            this.TB_TSS.Size = new System.Drawing.Size(499, 46);
            this.TB_TSS.TabIndex = 32;
            // 
            // TB_NH4
            // 
            this.TB_NH4.Animated = true;
            this.TB_NH4.AutoRoundedCorners = true;
            this.TB_NH4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.TB_NH4.BorderRadius = 22;
            this.TB_NH4.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TB_NH4.DefaultText = "";
            this.TB_NH4.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TB_NH4.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TB_NH4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_NH4.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_NH4.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_NH4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TB_NH4.ForeColor = System.Drawing.Color.Black;
            this.TB_NH4.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_NH4.Location = new System.Drawing.Point(797, 700);
            this.TB_NH4.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.TB_NH4.Name = "TB_NH4";
            this.TB_NH4.PasswordChar = '\0';
            this.TB_NH4.PlaceholderText = "Nhập Dữ Liệu NH4";
            this.TB_NH4.SelectedText = "";
            this.TB_NH4.Size = new System.Drawing.Size(499, 46);
            this.TB_NH4.TabIndex = 33;
            // 
            // TSS
            // 
            this.TSS.AutoSize = false;
            this.TSS.BackColor = System.Drawing.Color.Transparent;
            this.TSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TSS.Location = new System.Drawing.Point(791, 779);
            this.TSS.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TSS.Name = "TSS";
            this.TSS.Size = new System.Drawing.Size(240, 39);
            this.TSS.TabIndex = 30;
            this.TSS.Text = "TSS";
            // 
            // NH4
            // 
            this.NH4.AutoSize = false;
            this.NH4.BackColor = System.Drawing.Color.Transparent;
            this.NH4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NH4.Location = new System.Drawing.Point(791, 648);
            this.NH4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.NH4.Name = "NH4";
            this.NH4.Size = new System.Drawing.Size(240, 45);
            this.NH4.TabIndex = 31;
            this.NH4.Text = "NH4";
            // 
            // BoxCOD
            // 
            this.BoxCOD.Animated = true;
            this.BoxCOD.AutoRoundedCorners = true;
            this.BoxCOD.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.BoxCOD.BorderRadius = 22;
            this.BoxCOD.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.BoxCOD.DefaultText = "";
            this.BoxCOD.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.BoxCOD.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.BoxCOD.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxCOD.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxCOD.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxCOD.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BoxCOD.ForeColor = System.Drawing.Color.Black;
            this.BoxCOD.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxCOD.Location = new System.Drawing.Point(797, 436);
            this.BoxCOD.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.BoxCOD.Name = "BoxCOD";
            this.BoxCOD.PasswordChar = '\0';
            this.BoxCOD.PlaceholderText = "Nhập Dữ Liệu COD";
            this.BoxCOD.SelectedText = "";
            this.BoxCOD.Size = new System.Drawing.Size(499, 46);
            this.BoxCOD.TabIndex = 27;
            // 
            // BoxTOC
            // 
            this.BoxTOC.Animated = true;
            this.BoxTOC.AutoRoundedCorners = true;
            this.BoxTOC.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.BoxTOC.BorderRadius = 22;
            this.BoxTOC.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.BoxTOC.DefaultText = "";
            this.BoxTOC.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.BoxTOC.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.BoxTOC.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxTOC.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxTOC.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxTOC.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BoxTOC.ForeColor = System.Drawing.Color.Black;
            this.BoxTOC.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxTOC.Location = new System.Drawing.Point(107, 825);
            this.BoxTOC.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.BoxTOC.Name = "BoxTOC";
            this.BoxTOC.PasswordChar = '\0';
            this.BoxTOC.PlaceholderText = "Nhập Dữ Liệu TOC";
            this.BoxTOC.SelectedText = "";
            this.BoxTOC.Size = new System.Drawing.Size(496, 46);
            this.BoxTOC.TabIndex = 28;
            // 
            // BoxtongP
            // 
            this.BoxtongP.Animated = true;
            this.BoxtongP.AutoRoundedCorners = true;
            this.BoxtongP.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.BoxtongP.BorderRadius = 22;
            this.BoxtongP.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.BoxtongP.DefaultText = "";
            this.BoxtongP.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.BoxtongP.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.BoxtongP.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxtongP.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxtongP.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxtongP.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BoxtongP.ForeColor = System.Drawing.Color.Black;
            this.BoxtongP.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxtongP.Location = new System.Drawing.Point(107, 700);
            this.BoxtongP.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.BoxtongP.Name = "BoxtongP";
            this.BoxtongP.PasswordChar = '\0';
            this.BoxtongP.PlaceholderText = "Nhập Dữ Liệu Tổng Photpho";
            this.BoxtongP.SelectedText = "";
            this.BoxtongP.Size = new System.Drawing.Size(496, 46);
            this.BoxtongP.TabIndex = 29;
            // 
            // COD
            // 
            this.COD.AutoSize = false;
            this.COD.BackColor = System.Drawing.Color.Transparent;
            this.COD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.COD.Location = new System.Drawing.Point(792, 391);
            this.COD.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.COD.Name = "COD";
            this.COD.Size = new System.Drawing.Size(329, 37);
            this.COD.TabIndex = 24;
            this.COD.Text = "COD";
            // 
            // TOC
            // 
            this.TOC.AutoSize = false;
            this.TOC.BackColor = System.Drawing.Color.Transparent;
            this.TOC.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TOC.Location = new System.Drawing.Point(101, 779);
            this.TOC.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TOC.Name = "TOC";
            this.TOC.Size = new System.Drawing.Size(293, 39);
            this.TOC.TabIndex = 25;
            this.TOC.Text = "TOC";
            // 
            // O2
            // 
            this.O2.AutoSize = false;
            this.O2.BackColor = System.Drawing.Color.Transparent;
            this.O2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.O2.Location = new System.Drawing.Point(101, 648);
            this.O2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.O2.Name = "O2";
            this.O2.Size = new System.Drawing.Size(355, 45);
            this.O2.TabIndex = 26;
            this.O2.Text = "Tổng Photpho";
            // 
            // TB_nhiet_do
            // 
            this.TB_nhiet_do.Animated = true;
            this.TB_nhiet_do.AutoRoundedCorners = true;
            this.TB_nhiet_do.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.TB_nhiet_do.BorderRadius = 22;
            this.TB_nhiet_do.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TB_nhiet_do.DefaultText = "";
            this.TB_nhiet_do.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TB_nhiet_do.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TB_nhiet_do.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_nhiet_do.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_nhiet_do.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_nhiet_do.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TB_nhiet_do.ForeColor = System.Drawing.Color.Black;
            this.TB_nhiet_do.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_nhiet_do.Location = new System.Drawing.Point(797, 279);
            this.TB_nhiet_do.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.TB_nhiet_do.Name = "TB_nhiet_do";
            this.TB_nhiet_do.PasswordChar = '\0';
            this.TB_nhiet_do.PlaceholderText = "Nhập Dữ Liệu Nhiệt Độ";
            this.TB_nhiet_do.SelectedText = "";
            this.TB_nhiet_do.Size = new System.Drawing.Size(499, 46);
            this.TB_nhiet_do.TabIndex = 21;
            // 
            // LB_nhiet_do
            // 
            this.LB_nhiet_do.AutoSize = false;
            this.LB_nhiet_do.BackColor = System.Drawing.Color.Transparent;
            this.LB_nhiet_do.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB_nhiet_do.Location = new System.Drawing.Point(792, 223);
            this.LB_nhiet_do.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.LB_nhiet_do.Name = "LB_nhiet_do";
            this.LB_nhiet_do.Size = new System.Drawing.Size(322, 48);
            this.LB_nhiet_do.TabIndex = 20;
            this.LB_nhiet_do.Text = "Nhiệt Độ";
            // 
            // BoxTDS
            // 
            this.BoxTDS.Animated = true;
            this.BoxTDS.AutoRoundedCorners = true;
            this.BoxTDS.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.BoxTDS.BorderRadius = 22;
            this.BoxTDS.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.BoxTDS.DefaultText = "";
            this.BoxTDS.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.BoxTDS.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.BoxTDS.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxTDS.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxTDS.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxTDS.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BoxTDS.ForeColor = System.Drawing.Color.Black;
            this.BoxTDS.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxTDS.Location = new System.Drawing.Point(797, 119);
            this.BoxTDS.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.BoxTDS.Name = "BoxTDS";
            this.BoxTDS.PasswordChar = '\0';
            this.BoxTDS.PlaceholderText = "Nhập Dữ Liệu TDS";
            this.BoxTDS.SelectedText = "";
            this.BoxTDS.Size = new System.Drawing.Size(499, 46);
            this.BoxTDS.TabIndex = 11;
            // 
            // BoxDO
            // 
            this.BoxDO.Animated = true;
            this.BoxDO.AutoRoundedCorners = true;
            this.BoxDO.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.BoxDO.BorderRadius = 22;
            this.BoxDO.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.BoxDO.DefaultText = "";
            this.BoxDO.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.BoxDO.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.BoxDO.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxDO.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxDO.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxDO.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BoxDO.ForeColor = System.Drawing.Color.Black;
            this.BoxDO.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxDO.Location = new System.Drawing.Point(104, 436);
            this.BoxDO.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.BoxDO.Name = "BoxDO";
            this.BoxDO.PasswordChar = '\0';
            this.BoxDO.PlaceholderText = "Nhập Dữ Liệu DO";
            this.BoxDO.SelectedText = "";
            this.BoxDO.Size = new System.Drawing.Size(499, 46);
            this.BoxDO.TabIndex = 11;
            // 
            // BoxpH
            // 
            this.BoxpH.Animated = true;
            this.BoxpH.AutoRoundedCorners = true;
            this.BoxpH.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.BoxpH.BorderRadius = 22;
            this.BoxpH.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.BoxpH.DefaultText = "";
            this.BoxpH.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.BoxpH.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.BoxpH.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxpH.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxpH.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxpH.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BoxpH.ForeColor = System.Drawing.Color.Black;
            this.BoxpH.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxpH.Location = new System.Drawing.Point(104, 279);
            this.BoxpH.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.BoxpH.Name = "BoxpH";
            this.BoxpH.PasswordChar = '\0';
            this.BoxpH.PlaceholderText = "Nhập Dữ Liệu pH";
            this.BoxpH.SelectedText = "";
            this.BoxpH.Size = new System.Drawing.Size(499, 46);
            this.BoxpH.TabIndex = 11;
            // 
            // savechange
            // 
            this.savechange.Animated = true;
            this.savechange.AutoRoundedCorners = true;
            this.savechange.BackColor = System.Drawing.Color.Transparent;
            this.savechange.BorderRadius = 21;
            this.savechange.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.savechange.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.savechange.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.savechange.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.savechange.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(167)))), ((int)(((byte)(67)))));
            this.savechange.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.savechange.ForeColor = System.Drawing.Color.White;
            this.savechange.IndicateFocus = true;
            this.savechange.Location = new System.Drawing.Point(545, 911);
            this.savechange.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.savechange.Name = "savechange";
            this.savechange.Size = new System.Drawing.Size(332, 45);
            this.savechange.TabIndex = 9;
            this.savechange.Text = "Lưu Dữ Liệu Hiện Trường";
            this.savechange.UseTransparentBackground = true;
            this.savechange.Click += new System.EventHandler(this.savechange_Click);
            // 
            // TDS
            // 
            this.TDS.AutoSize = false;
            this.TDS.BackColor = System.Drawing.Color.Transparent;
            this.TDS.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TDS.Location = new System.Drawing.Point(792, 71);
            this.TDS.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TDS.Name = "TDS";
            this.TDS.Size = new System.Drawing.Size(298, 40);
            this.TDS.TabIndex = 2;
            this.TDS.Text = "TDS";
            // 
            // BO
            // 
            this.BO.AutoSize = false;
            this.BO.BackColor = System.Drawing.Color.Transparent;
            this.BO.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BO.Location = new System.Drawing.Point(98, 383);
            this.BO.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BO.Name = "BO";
            this.BO.Size = new System.Drawing.Size(298, 46);
            this.BO.TabIndex = 2;
            this.BO.Text = "DO";
            // 
            // pH
            // 
            this.pH.AutoSize = false;
            this.pH.BackColor = System.Drawing.Color.Transparent;
            this.pH.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pH.Location = new System.Drawing.Point(98, 223);
            this.pH.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pH.Name = "pH";
            this.pH.Size = new System.Drawing.Size(298, 49);
            this.pH.TabIndex = 2;
            this.pH.Text = "pH";
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.AutoSize = false;
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(32, 2);
            this.guna2HtmlLabel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(560, 65);
            this.guna2HtmlLabel1.TabIndex = 1;
            this.guna2HtmlLabel1.Text = "Nhập Chi Tiết Dữ Liệu";
            // 
            // guna2Panel2
            // 
            this.guna2Panel2.Controls.Add(this.guna2HtmlLabel9);
            this.guna2Panel2.Location = new System.Drawing.Point(12, 16);
            this.guna2Panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel2.Name = "guna2Panel2";
            this.guna2Panel2.Size = new System.Drawing.Size(1449, 75);
            this.guna2Panel2.TabIndex = 13;
            // 
            // guna2HtmlLabel9
            // 
            this.guna2HtmlLabel9.AutoSize = false;
            this.guna2HtmlLabel9.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel9.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(188)))), ((int)(((byte)(109)))));
            this.guna2HtmlLabel9.Location = new System.Drawing.Point(3, 2);
            this.guna2HtmlLabel9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel9.Name = "guna2HtmlLabel9";
            this.guna2HtmlLabel9.Size = new System.Drawing.Size(662, 63);
            this.guna2HtmlLabel9.TabIndex = 0;
            this.guna2HtmlLabel9.Text = "Dữ Liệu Hiện Trường Nước Mặt";
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 30;
            // 
            // chi_tieu_nuoc_mat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1473, 1106);
            this.Controls.Add(this.guna2Panel1);
            this.Controls.Add(this.guna2Panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "chi_tieu_nuoc_mat";
            this.Text = "chi_tieu_nuoc_mat";
            this.guna2Panel1.ResumeLayout(false);
            this.guna2Panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2TextBox TB_nhiet_do;
        private Guna.UI2.WinForms.Guna2HtmlLabel LB_nhiet_do;
        private Guna.UI2.WinForms.Guna2TextBox BoxTDS;
        private Guna.UI2.WinForms.Guna2TextBox BoxDO;
        private Guna.UI2.WinForms.Guna2TextBox BoxpH;
        private Guna.UI2.WinForms.Guna2Button savechange;
        private Guna.UI2.WinForms.Guna2HtmlLabel TDS;
        private Guna.UI2.WinForms.Guna2HtmlLabel BO;
        private Guna.UI2.WinForms.Guna2HtmlLabel pH;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel9;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2TextBox TB_NO3;
        private Guna.UI2.WinForms.Guna2HtmlLabel NO3;
        private Guna.UI2.WinForms.Guna2TextBox TB_PO4;
        private Guna.UI2.WinForms.Guna2HtmlLabel PO4;
        private Guna.UI2.WinForms.Guna2TextBox TB_tongN;
        private Guna.UI2.WinForms.Guna2HtmlLabel tongP;
        private Guna.UI2.WinForms.Guna2TextBox TB_TSS;
        private Guna.UI2.WinForms.Guna2TextBox TB_NH4;
        private Guna.UI2.WinForms.Guna2HtmlLabel TSS;
        private Guna.UI2.WinForms.Guna2HtmlLabel NH4;
        private Guna.UI2.WinForms.Guna2TextBox BoxCOD;
        private Guna.UI2.WinForms.Guna2TextBox BoxTOC;
        private Guna.UI2.WinForms.Guna2TextBox BoxtongP;
        private Guna.UI2.WinForms.Guna2HtmlLabel COD;
        private Guna.UI2.WinForms.Guna2HtmlLabel TOC;
        private Guna.UI2.WinForms.Guna2HtmlLabel O2;
    }
}