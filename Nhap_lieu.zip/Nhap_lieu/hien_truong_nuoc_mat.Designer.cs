﻿namespace EcoProject.Nhap_lieu
{
    partial class hien_truong_nuoc_mat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.TB_nhiet_do = new Guna.UI2.WinForms.Guna2TextBox();
            this.LB_nhiet_do = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.vi_tri_lay_mau = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.BoxTDS = new Guna.UI2.WinForms.Guna2TextBox();
            this.BoxDO = new Guna.UI2.WinForms.Guna2TextBox();
            this.BoxpH = new Guna.UI2.WinForms.Guna2TextBox();
            this.savechange = new Guna.UI2.WinForms.Guna2Button();
            this.TDS = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.BO = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.pH = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2HtmlLabel9 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel2.SuspendLayout();
            this.guna2Panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // TB_nhiet_do
            // 
            this.TB_nhiet_do.Animated = true;
            this.TB_nhiet_do.AutoRoundedCorners = true;
            this.TB_nhiet_do.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.TB_nhiet_do.BorderRadius = 22;
            this.TB_nhiet_do.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TB_nhiet_do.DefaultText = "";
            this.TB_nhiet_do.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TB_nhiet_do.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TB_nhiet_do.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_nhiet_do.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TB_nhiet_do.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_nhiet_do.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TB_nhiet_do.ForeColor = System.Drawing.Color.Black;
            this.TB_nhiet_do.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TB_nhiet_do.Location = new System.Drawing.Point(797, 279);
            this.TB_nhiet_do.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.TB_nhiet_do.Name = "TB_nhiet_do";
            this.TB_nhiet_do.PasswordChar = '\0';
            this.TB_nhiet_do.PlaceholderText = "Nhập Dữ Liệu Nhiệt Độ";
            this.TB_nhiet_do.SelectedText = "";
            this.TB_nhiet_do.Size = new System.Drawing.Size(499, 46);
            this.TB_nhiet_do.TabIndex = 21;
            // 
            // LB_nhiet_do
            // 
            this.LB_nhiet_do.AutoSize = false;
            this.LB_nhiet_do.BackColor = System.Drawing.Color.Transparent;
            this.LB_nhiet_do.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB_nhiet_do.Location = new System.Drawing.Point(792, 223);
            this.LB_nhiet_do.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.LB_nhiet_do.Name = "LB_nhiet_do";
            this.LB_nhiet_do.Size = new System.Drawing.Size(322, 48);
            this.LB_nhiet_do.TabIndex = 20;
            this.LB_nhiet_do.Text = "Nhiệt Độ";
            // 
            // vi_tri_lay_mau
            // 
            this.vi_tri_lay_mau.Animated = true;
            this.vi_tri_lay_mau.AutoRoundedCorners = true;
            this.vi_tri_lay_mau.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.vi_tri_lay_mau.BorderRadius = 22;
            this.vi_tri_lay_mau.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.vi_tri_lay_mau.DefaultText = "";
            this.vi_tri_lay_mau.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.vi_tri_lay_mau.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.vi_tri_lay_mau.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.vi_tri_lay_mau.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.vi_tri_lay_mau.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.vi_tri_lay_mau.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.vi_tri_lay_mau.ForeColor = System.Drawing.Color.Black;
            this.vi_tri_lay_mau.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.vi_tri_lay_mau.Location = new System.Drawing.Point(104, 119);
            this.vi_tri_lay_mau.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.vi_tri_lay_mau.Name = "vi_tri_lay_mau";
            this.vi_tri_lay_mau.PasswordChar = '\0';
            this.vi_tri_lay_mau.PlaceholderText = "Nhập Vị Trí Lấy Mẫu";
            this.vi_tri_lay_mau.SelectedText = "";
            this.vi_tri_lay_mau.Size = new System.Drawing.Size(499, 46);
            this.vi_tri_lay_mau.TabIndex = 19;
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.AutoSize = false;
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(98, 71);
            this.guna2HtmlLabel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(331, 41);
            this.guna2HtmlLabel2.TabIndex = 13;
            this.guna2HtmlLabel2.Text = "Vị trí lấy mẫu";
            // 
            // BoxTDS
            // 
            this.BoxTDS.Animated = true;
            this.BoxTDS.AutoRoundedCorners = true;
            this.BoxTDS.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.BoxTDS.BorderRadius = 22;
            this.BoxTDS.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.BoxTDS.DefaultText = "";
            this.BoxTDS.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.BoxTDS.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.BoxTDS.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxTDS.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxTDS.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxTDS.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BoxTDS.ForeColor = System.Drawing.Color.Black;
            this.BoxTDS.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxTDS.Location = new System.Drawing.Point(797, 119);
            this.BoxTDS.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.BoxTDS.Name = "BoxTDS";
            this.BoxTDS.PasswordChar = '\0';
            this.BoxTDS.PlaceholderText = "Nhập Dữ Liệu TDS";
            this.BoxTDS.SelectedText = "";
            this.BoxTDS.Size = new System.Drawing.Size(499, 46);
            this.BoxTDS.TabIndex = 11;
            // 
            // BoxDO
            // 
            this.BoxDO.Animated = true;
            this.BoxDO.AutoRoundedCorners = true;
            this.BoxDO.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.BoxDO.BorderRadius = 22;
            this.BoxDO.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.BoxDO.DefaultText = "";
            this.BoxDO.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.BoxDO.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.BoxDO.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxDO.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxDO.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxDO.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BoxDO.ForeColor = System.Drawing.Color.Black;
            this.BoxDO.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxDO.Location = new System.Drawing.Point(104, 436);
            this.BoxDO.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.BoxDO.Name = "BoxDO";
            this.BoxDO.PasswordChar = '\0';
            this.BoxDO.PlaceholderText = "Nhập Dữ Liệu DO";
            this.BoxDO.SelectedText = "";
            this.BoxDO.Size = new System.Drawing.Size(499, 46);
            this.BoxDO.TabIndex = 11;
            // 
            // BoxpH
            // 
            this.BoxpH.Animated = true;
            this.BoxpH.AutoRoundedCorners = true;
            this.BoxpH.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(202)))), ((int)(((byte)(144)))));
            this.BoxpH.BorderRadius = 22;
            this.BoxpH.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.BoxpH.DefaultText = "";
            this.BoxpH.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.BoxpH.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.BoxpH.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxpH.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.BoxpH.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxpH.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BoxpH.ForeColor = System.Drawing.Color.Black;
            this.BoxpH.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.BoxpH.Location = new System.Drawing.Point(104, 279);
            this.BoxpH.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.BoxpH.Name = "BoxpH";
            this.BoxpH.PasswordChar = '\0';
            this.BoxpH.PlaceholderText = "Nhập Dữ Liệu pH";
            this.BoxpH.SelectedText = "";
            this.BoxpH.Size = new System.Drawing.Size(499, 46);
            this.BoxpH.TabIndex = 11;
            // 
            // savechange
            // 
            this.savechange.Animated = true;
            this.savechange.AutoRoundedCorners = true;
            this.savechange.BackColor = System.Drawing.Color.Transparent;
            this.savechange.BorderRadius = 21;
            this.savechange.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.savechange.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.savechange.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.savechange.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.savechange.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(167)))), ((int)(((byte)(67)))));
            this.savechange.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.savechange.ForeColor = System.Drawing.Color.White;
            this.savechange.IndicateFocus = true;
            this.savechange.Location = new System.Drawing.Point(517, 591);
            this.savechange.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.savechange.Name = "savechange";
            this.savechange.Size = new System.Drawing.Size(332, 45);
            this.savechange.TabIndex = 9;
            this.savechange.Text = "Lưu Dữ Liệu Hiện Trường";
            this.savechange.UseTransparentBackground = true;
            this.savechange.Click += new System.EventHandler(this.savechange_Click);
            // 
            // TDS
            // 
            this.TDS.AutoSize = false;
            this.TDS.BackColor = System.Drawing.Color.Transparent;
            this.TDS.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TDS.Location = new System.Drawing.Point(792, 71);
            this.TDS.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TDS.Name = "TDS";
            this.TDS.Size = new System.Drawing.Size(298, 40);
            this.TDS.TabIndex = 2;
            this.TDS.Text = "TDS";
            // 
            // BO
            // 
            this.BO.AutoSize = false;
            this.BO.BackColor = System.Drawing.Color.Transparent;
            this.BO.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BO.Location = new System.Drawing.Point(98, 383);
            this.BO.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BO.Name = "BO";
            this.BO.Size = new System.Drawing.Size(298, 46);
            this.BO.TabIndex = 2;
            this.BO.Text = "DO";
            // 
            // pH
            // 
            this.pH.AutoSize = false;
            this.pH.BackColor = System.Drawing.Color.Transparent;
            this.pH.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pH.Location = new System.Drawing.Point(98, 223);
            this.pH.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pH.Name = "pH";
            this.pH.Size = new System.Drawing.Size(298, 49);
            this.pH.TabIndex = 2;
            this.pH.Text = "pH";
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.AutoSize = false;
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(32, 2);
            this.guna2HtmlLabel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(560, 65);
            this.guna2HtmlLabel1.TabIndex = 1;
            this.guna2HtmlLabel1.Text = "Nhập Chi Tiết Dữ Liệu";
            // 
            // guna2Panel2
            // 
            this.guna2Panel2.Controls.Add(this.guna2HtmlLabel9);
            this.guna2Panel2.Location = new System.Drawing.Point(12, 16);
            this.guna2Panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel2.Name = "guna2Panel2";
            this.guna2Panel2.Size = new System.Drawing.Size(1449, 75);
            this.guna2Panel2.TabIndex = 11;
            // 
            // guna2HtmlLabel9
            // 
            this.guna2HtmlLabel9.AutoSize = false;
            this.guna2HtmlLabel9.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel9.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(188)))), ((int)(((byte)(109)))));
            this.guna2HtmlLabel9.Location = new System.Drawing.Point(3, 2);
            this.guna2HtmlLabel9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2HtmlLabel9.Name = "guna2HtmlLabel9";
            this.guna2HtmlLabel9.Size = new System.Drawing.Size(662, 63);
            this.guna2HtmlLabel9.TabIndex = 0;
            this.guna2HtmlLabel9.Text = "Dữ Liệu Hiện Trường Nước Mặt";
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 30;
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.Controls.Add(this.TB_nhiet_do);
            this.guna2Panel1.Controls.Add(this.LB_nhiet_do);
            this.guna2Panel1.Controls.Add(this.vi_tri_lay_mau);
            this.guna2Panel1.Controls.Add(this.guna2HtmlLabel2);
            this.guna2Panel1.Controls.Add(this.BoxTDS);
            this.guna2Panel1.Controls.Add(this.BoxDO);
            this.guna2Panel1.Controls.Add(this.BoxpH);
            this.guna2Panel1.Controls.Add(this.savechange);
            this.guna2Panel1.Controls.Add(this.TDS);
            this.guna2Panel1.Controls.Add(this.BO);
            this.guna2Panel1.Controls.Add(this.pH);
            this.guna2Panel1.Controls.Add(this.guna2HtmlLabel1);
            this.guna2Panel1.Location = new System.Drawing.Point(12, 96);
            this.guna2Panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.Size = new System.Drawing.Size(1449, 683);
            this.guna2Panel1.TabIndex = 10;
            // 
            // hien_truong_nuoc_mat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(144F, 144F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(1473, 795);
            this.Controls.Add(this.guna2Panel2);
            this.Controls.Add(this.guna2Panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "hien_truong_nuoc_mat";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "hien_truong_nuoc_mat";
            this.guna2Panel2.ResumeLayout(false);
            this.guna2Panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2TextBox TB_nhiet_do;
        private Guna.UI2.WinForms.Guna2HtmlLabel LB_nhiet_do;
        private Guna.UI2.WinForms.Guna2TextBox vi_tri_lay_mau;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2TextBox BoxTDS;
        private Guna.UI2.WinForms.Guna2TextBox BoxDO;
        private Guna.UI2.WinForms.Guna2TextBox BoxpH;
        private Guna.UI2.WinForms.Guna2Button savechange;
        private Guna.UI2.WinForms.Guna2HtmlLabel TDS;
        private Guna.UI2.WinForms.Guna2HtmlLabel BO;
        private Guna.UI2.WinForms.Guna2HtmlLabel pH;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel9;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
    }
}